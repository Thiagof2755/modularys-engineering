import React from 'react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ActivityData } from './Apontamentos';
import styled from 'styled-components';
import { modernTechTheme, typography, layout, type PDFTheme } from './PDFExportStyles'; // Removido getActivityIcon

// Stats interface
interface ActivityStats {
    total: number;
    totalTime: string;
    uniqueUsers: number;
    avgTime: string;
}

// Export options interface
interface ExportOptions {
    theme?: PDFTheme;
    includeStats?: boolean;
    includeCompanyInfo?: boolean;
    watermark?: string;
}

// Styled components for preview (if needed)
const PreviewContainer = styled.div`
    display: none; // Hidden by default
`;

// Helper functions
const formatTime = (timeStr: string): string => {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return `${hours}h ${minutes}min`;
};

const formatDate = (dateStr: string): string => {
    try {
        const parts = dateStr.split('/');
        if (parts.length !== 3) return dateStr;

        const day = parts[0].padStart(2, '0');
        const month = parts[1].padStart(2, '0');
        const year = parts[2];

        return `${day}/${month}/${year}`;
    } catch (error) {
        return dateStr;
    }
};

class PDFExport {
    // Modern tech company color palette with blue tones
    private static readonly colors = {
        primary: [20, 74, 140], // #144a8c - Professional tech blue
        secondary: [59, 130, 246], // #3b82f6 - Bright modern blue
        accent: [99, 179, 237], // #63b3ed - Light accent blue
        gradient: {
            start: [30, 64, 175], // #1e40af
            end: [59, 130, 246], // #3b82f6
        },
        background: {
            main: [248, 250, 252], // #f8fafc - Clean background
            white: [255, 255, 255], // Pure white
            card: [255, 255, 255], // Card background
            section: [241, 245, 249], // #f1f5f9 - Section background
        },
        text: {
            primary: [30, 41, 59], // #1e293b - Dark professional
            secondary: [71, 85, 105], // #475569 - Medium gray
            muted: [148, 163, 184], // #94a3b8 - Light gray
            white: [255, 255, 255], // White text
        },
        border: [226, 232, 240], // #e2e8f0 - Light border
        success: [34, 197, 94], // #22c55e - Success green
        warning: [251, 191, 36], // #fbbf24 - Warning yellow
        shadow: [0, 0, 0, 0.1] // Subtle shadow
    };

    // Add rounded rectangle with modern shadow effect
    private static addRoundedRect(doc: jsPDF, x: number, y: number, width: number, height: number, radius: number = 4, fillColor?: number[], strokeColor?: number[], addShadow: boolean = true) {
        // Add subtle shadow first
        if (addShadow) {
            doc.setFillColor(0, 0, 0, 0.05);
            doc.roundedRect(x + 1, y + 1, width, height, radius, radius, 'F');
        }
        
        // Main rounded rectangle
        if (fillColor) {
            doc.setFillColor(fillColor[0], fillColor[1], fillColor[2]);
            doc.roundedRect(x, y, width, height, radius, radius, 'F');
        }
        if (strokeColor) {
            doc.setDrawColor(strokeColor[0], strokeColor[1], strokeColor[2]);
            doc.setLineWidth(0.5);
            doc.roundedRect(x, y, width, height, radius, radius, 'S');
        }
    }

    // Add gradient background effect
    private static addGradientHeader(doc: jsPDF, x: number, y: number, width: number, height: number) {
        // Create gradient effect with multiple rectangles
        const steps = 20;
        const stepHeight = height / steps;
        
        for (let i = 0; i < steps; i++) {
            const ratio = i / (steps - 1);
            const r = Math.round(this.colors.gradient.start[0] + (this.colors.gradient.end[0] - this.colors.gradient.start[0]) * ratio);
            const g = Math.round(this.colors.gradient.start[1] + (this.colors.gradient.end[1] - this.colors.gradient.start[1]) * ratio);
            const b = Math.round(this.colors.gradient.start[2] + (this.colors.gradient.end[2] - this.colors.gradient.start[2]) * ratio);
            
            doc.setFillColor(r, g, b);
            doc.rect(x, y + i * stepHeight, width, stepHeight + 0.1, 'F');
        }
    }

    // Add decorative elements (removed circles)
    private static addDecorativeElements(doc: jsPDF, x: number, y: number, width: number) {
        // Add tech-style decorative lines
        doc.setDrawColor(this.colors.accent[0], this.colors.accent[1], this.colors.accent[2]);
        doc.setLineWidth(2);
        
        // Top accent line
        doc.line(x + 20, y + 8, x + width - 20, y + 8);
        
        // Side accent elements (removed circles)
    }

    // Add simple rectangle (keeping for backward compatibility)
    private static addRect(doc: jsPDF, x: number, y: number, width: number, height: number, fillColor?: number[], strokeColor?: number[]) {
        if (fillColor) {
            doc.setFillColor(fillColor[0], fillColor[1], fillColor[2]);
            doc.rect(x, y, width, height, 'F');
        }
        if (strokeColor) {
            doc.setDrawColor(strokeColor[0], strokeColor[1], strokeColor[2]);
            doc.setLineWidth(0.5);
            doc.rect(x, y, width, height, 'S');
        }
    }

    // Modern header with gradient and rounded corners (removed logo circles)
    private static addHeader(doc: jsPDF, activityData: ActivityData): number {
        const pageWidth = doc.internal.pageSize.getWidth();
        let yPos = 20;

        // Main header card with gradient background
        this.addGradientHeader(doc, 15, yPos, pageWidth - 30, 50);
        this.addRoundedRect(doc, 15, yPos, pageWidth - 30, 50, 8, undefined, undefined, false);

        // Add decorative elements (lines only, circles removed)
        this.addDecorativeElements(doc, 15, yPos, pageWidth - 30);

        // Title with modern styling
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(20);
        doc.setTextColor(this.colors.text.white[0], this.colors.text.white[1], this.colors.text.white[2]);
        doc.text(activityData.dashboard_info.title, 35, yPos + 22); // Adjusted X position

        // Date subtitle with modern styling
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(12);
        doc.setTextColor(this.colors.text.white[0], this.colors.text.white[1], this.colors.text.white[2]);
        doc.text(activityData.dashboard_info.date, 35, yPos + 35); // Adjusted X position

        // Last update badge (modern rounded pill)
        const updateText = `Atualizado em: ${activityData.dashboard_info.last_update}`;
        const updateWidth = doc.getTextWidth(updateText) + 20;
        this.addRoundedRect(doc, pageWidth - updateWidth - 25, yPos + 40, updateWidth, 14, 7, this.colors.background.white);
        
        doc.setFont('helvetica', 'medium');
        doc.setFontSize(9);
        doc.setTextColor(this.colors.primary[0], this.colors.primary[1], this.colors.primary[2]);
        doc.text(updateText, pageWidth - updateWidth - 15, yPos + 48);

        return yPos + 70;
    }

    // Modern companies section with cards (removed icons)
    private static addCompaniesSection(doc: jsPDF, activityData: ActivityData, yPos: number): number {
        const pageWidth = doc.internal.pageSize.getWidth();
        const cardGap = 10; // Gap between cards
        const totalCardAreaWidth = pageWidth - 30 - cardGap; // 30 (15*2) for outer margins, 10 for inner gap
        const cardWidth = totalCardAreaWidth / 2; // Two cards side by side with gap

        // Executing company card with modern styling
        this.addRoundedRect(doc, 15, yPos, cardWidth, 35, 8, this.colors.background.white, this.colors.border);
        
        doc.setFont('helvetica', 'medium');
        doc.setFontSize(10);
        doc.setTextColor(this.colors.text.secondary[0], this.colors.text.secondary[1], this.colors.text.secondary[2]);
        doc.text('Empresa Executora', 25, yPos + 12); // Adjusted X position
        
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(13);
        doc.setTextColor(this.colors.text.primary[0], this.colors.text.primary[1], this.colors.text.primary[2]);
        const executingLines = doc.splitTextToSize(activityData.companies.executing_company, cardWidth - 25);
        doc.text(executingLines, 25, yPos + 24); // Adjusted X position

        // Contracting company card with modern styling
        const secondCardX = 15 + cardWidth + cardGap; // Start after first card + gap
        this.addRoundedRect(doc, secondCardX, yPos, cardWidth, 35, 8, this.colors.background.white, this.colors.border);
        
        doc.setFont('helvetica', 'medium');
        doc.setFontSize(10);
        doc.setTextColor(this.colors.text.secondary[0], this.colors.text.secondary[1], this.colors.text.secondary[2]);
        doc.text('Empresa Contratante', secondCardX + 10, yPos + 12); // Adjusted X position
        
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(13);
        doc.setTextColor(this.colors.text.primary[0], this.colors.text.primary[1], this.colors.text.primary[2]);
        const contractingLines = doc.splitTextToSize(activityData.companies.contracting_company, cardWidth - 25);
        doc.text(contractingLines, secondCardX + 10, yPos + 24); // Adjusted X position

        return yPos + 50; // Increased spacing slightly
    }

    // Modern stats section with gradient cards (removed icon circles)
    private static addStatsSection(doc: jsPDF, stats: ActivityStats, yPos: number): number {
        const pageWidth = doc.internal.pageSize.getWidth();
        
        // Section title with modern styling
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(16);
        doc.setTextColor(this.colors.primary[0], this.colors.primary[1], this.colors.primary[2]);
        doc.text('Resumo de Atividades', 20, yPos + 15);

        // Modern stats grid (4 cards)
        const cardGap = 10;
        const totalStatsWidth = pageWidth - 40 - (3 * cardGap); // 40 for 20*2 margins, 3 gaps
        const cardWidth = totalStatsWidth / 4;
        const cardHeight = 35; // Fixed height for stat cards
        const statsData = [
            { label: 'Total de Atividades', value: stats.total.toString(), color: this.colors.secondary },
            { label: 'Tempo Total', value: formatTime(stats.totalTime), color: this.colors.accent },
            { label: 'Responsáveis', value: stats.uniqueUsers.toString(), color: this.colors.primary },
            { label: 'Tempo Médio', value: formatTime(stats.avgTime), color: this.colors.success }
        ];

        statsData.forEach((stat, index) => {
            const x = 20 + (index * (cardWidth + cardGap));
            const cardY = yPos + 25; // Y position for the stat card
            
            // Modern stat card with gradient and shadow
            this.addRoundedRect(doc, x, cardY, cardWidth, cardHeight, 8, this.colors.background.white, undefined, true);
            
            // Accent border on top
            this.addRoundedRect(doc, x, cardY, cardWidth, 3, 2, stat.color);
            
            // Value (large and prominent)
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(16);
            doc.setTextColor(this.colors.primary[0], this.colors.primary[1], this.colors.primary[2]);
            doc.text(stat.value, x + cardWidth/2, cardY + 20, { align: 'center' });
            
            // Label (smaller, below value)
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(8);
            doc.setTextColor(this.colors.text.secondary[0], this.colors.text.secondary[1], this.colors.text.secondary[2]);
            const labelLines = doc.splitTextToSize(stat.label, cardWidth - 8);
            const labelYOffset = (labelLines.length > 1) ? 3 : 0; // Small adjustment for multi-line labels
            doc.text(labelLines, x + cardWidth/2, cardY + 30 + labelYOffset, { align: 'center' });
        });

        return yPos + 80; // Increased spacing slightly
    }

    // Modern activity card with enhanced design and page break protection
    private static addActivityCard(doc: jsPDF, entry: any, index: number, yPos: number): number {
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        
        // Estimate line height for different font sizes
        const lineHeight14pt = 5; // For main title
        const lineHeight10pt = 4; // For description
        const lineHeight9pt = 3.5; // For meta value
        const lineHeight8pt = 3; // For meta label (approximate)

        // Calculate height for title (14pt)
        doc.setFontSize(14);
        const titleLines = doc.splitTextToSize(entry.atividade, pageWidth - 100);
        const titleHeight = titleLines.length * lineHeight14pt;

        // Calculate height for description (10pt)
        doc.setFontSize(10);
        const descriptionLines = doc.splitTextToSize(entry.descritivo, pageWidth - 60);
        const descriptionTextHeight = descriptionLines.length * lineHeight10pt;

        // Calculate height for meta info (9pt value, 8pt label)
        doc.setFontSize(9);
        let maxMetaValueLines = 1;
        const metaWidth = (pageWidth - 70) / 3;
        const metaCards = [
            { label: 'Responsável', value: entry.responsavel },
            { label: 'Solicitante', value: entry.solicitante },
            { label: 'Data', value: formatDate(entry.data) }
        ];
        metaCards.forEach(meta => {
            const valueLines = doc.splitTextToSize(meta.value, metaWidth - 10);
            if (valueLines.length > maxMetaValueLines) {
                maxMetaValueLines = valueLines.length;
            }
        });

        // Refined meta card height calculation for compactness
        const paddingTopInMetaCard = 4; // Reduced from 5
        const paddingBottomInMetaCard = 4; // Reduced from 5
        const labelToValueGap = 1.5; // Reduced from 2
        const metaInfoRowHeight = paddingTopInMetaCard + lineHeight8pt + labelToValueGap + (maxMetaValueLines * lineHeight9pt) + paddingBottomInMetaCard;

        // Calculate total card content height dynamically
        let currentContentHeight = 0;
        currentContentHeight += 10; // Initial top padding inside card (before title)
        currentContentHeight += titleHeight; // Title height
        currentContentHeight += 8; // Padding after title to company tag
        currentContentHeight += 10; // Company tag (approx height)
        currentContentHeight += 10; // Padding after company tag to meta info
        currentContentHeight += metaInfoRowHeight; // Meta info row height
        currentContentHeight += 15; // Padding after meta info to description header
        currentContentHeight += 10; // Description header (approx height)
        currentContentHeight += descriptionTextHeight; // Description text
        currentContentHeight += 15; // Bottom padding after description

        const cardHeight = currentContentHeight;

        // CRITICAL: Check if card fits on current page - if not, add new page
        if (yPos + cardHeight > pageHeight - 40) { // 40mm buffer for footer and bottom margin
            doc.addPage();
            // Set page background for new page
            this.addRect(doc, 0, 0, pageWidth, pageHeight, this.colors.background.main);
            yPos = 30; // Reset yPos for new page
        }

        // Modern activity card with gradient accent and shadow
        this.addRoundedRect(doc, 15, yPos, pageWidth - 30, cardHeight, 12, this.colors.background.white, undefined, true);

        // Status indicator (left accent border)
        this.addRoundedRect(doc, 15, yPos, 4, cardHeight, 2, this.colors.secondary);

        // --- Start positioning content within the card ---
        let currentCardY = yPos + 10; // Initial Y position for content inside the card, 10mm from card top

        // Priority/Status badge (top right)
        const statusBadgeWidth = 60;
        this.addRoundedRect(doc, pageWidth - statusBadgeWidth - 25, currentCardY, statusBadgeWidth, 16, 8, this.colors.success);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(this.colors.text.white[0], this.colors.text.white[1], this.colors.text.white[2]);
        doc.text('CONCLUÍDO', pageWidth - statusBadgeWidth/2 - 25, currentCardY + 9, { align: 'center' });

        // Activity title with modern typography
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(14);
        doc.setTextColor(this.colors.text.primary[0], this.colors.text.primary[1], this.colors.text.primary[2]);
        doc.text(titleLines, 30, currentCardY + 8); // 8mm from currentCardY
        currentCardY += titleHeight + 8; // Move Y after title + padding

        // Company tag
        doc.setFont('helvetica', 'medium');
        doc.setFontSize(10);
        doc.setTextColor(this.colors.text.secondary[0], this.colors.text.secondary[1], this.colors.text.secondary[2]);
        doc.text(`${entry.empresa}`, 30, currentCardY);
        currentCardY += 10; // Move Y after company tag + padding

        // Time badge (modern pill shape)
        const timeText = formatTime(entry.tempo_gasto);
        const timeWidth = doc.getTextWidth(timeText) + 20;
        // This time badge is positioned relative to the card's top, not currentCardY.
        // It's fixed at yPos + 30, which is fine.
        this.addRoundedRect(doc, pageWidth - timeWidth - 25, yPos + 30, timeWidth, 16, 8, this.colors.accent);
        
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(this.colors.text.white[0], this.colors.text.white[1], this.colors.text.white[2]);
        doc.text(`${timeText}`, pageWidth - timeWidth - 15, yPos + 40);

        // Meta information row with modern styling
        const metaCardGap = 5; // Gap between meta cards
        const metaCardTotalWidth = pageWidth - 30 - (2 * metaCardGap); // Total width for 3 cards + 2 gaps
        const singleMetaCardWidth = metaCardTotalWidth / 3;

        metaCards.forEach((meta, idx) => {
            const metaX = 15 + (idx * (singleMetaCardWidth + metaCardGap));
            
            // Meta card background
            this.addRoundedRect(doc, metaX, currentCardY, singleMetaCardWidth, metaInfoRowHeight, 6, this.colors.background.section);
            
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(8); // Label font size
            doc.setTextColor(this.colors.text.secondary[0], this.colors.text.secondary[1], this.colors.text.secondary[2]);
            doc.text(meta.label, metaX + 5, currentCardY + paddingTopInMetaCard); // Label Y
            
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(9); // Value font size
            doc.setTextColor(this.colors.text.primary[0], this.colors.text.primary[1], this.colors.text.primary[2]);
            const valueLines = doc.splitTextToSize(meta.value, singleMetaCardWidth - 10);
            doc.text(valueLines, metaX + 5, currentCardY + paddingTopInMetaCard + lineHeight8pt + labelToValueGap); // Value Y
        });
        currentCardY += metaInfoRowHeight + 15; // Move Y after meta cards + padding

        // Description section with modern styling
        const descY = currentCardY;
        const descTotalHeight = descriptionTextHeight + 20; // Added internal padding for description box
        this.addRoundedRect(doc, 25, descY, pageWidth - 50, descTotalHeight, 8, this.colors.background.card);
        
        // Modern accent border (left side)
        this.addRoundedRect(doc, 25, descY, 3, descTotalHeight, 2, this.colors.secondary);

        // Description header
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(this.colors.primary[0], this.colors.primary[1], this.colors.primary[2]);
        doc.text('Descrição da Atividade', 35, descY + 10);

        // Description text with better formatting
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(this.colors.text.primary[0], this.colors.text.primary[1], this.colors.text.primary[2]);
        doc.text(descriptionLines, 35, descY + 20);

        return yPos + cardHeight + 20; // Return new Y position with spacing after the card
    }

    // Modern footer with gradient and professional styling (removed circles)
    private static addFooter(doc: jsPDF, activityData: ActivityData) {
        const totalPages = doc.getNumberOfPages();
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        
        for (let i = 1; i <= totalPages; i++) {
            doc.setPage(i);
            
            // Modern footer background with gradient
            const footerY = pageHeight - 25;
            this.addGradientHeader(doc, 0, footerY, pageWidth, 25);
            
            // Company branding
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(11);
            doc.setTextColor(this.colors.text.white[0], this.colors.text.white[1], this.colors.text.white[2]);
            doc.text(
                `Relatório de Atividades | ${activityData.companies.executing_company}`,
                pageWidth / 2,
                footerY + 10,
                { align: 'center' }
            );
            
            // Modern page number with styling
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(9);
            doc.setTextColor(this.colors.text.white[0], this.colors.text.white[1], this.colors.text.white[2]);
            doc.text(
                `Página ${i} de ${totalPages} • Gerado em ${new Date().toLocaleDateString('pt-BR')}`,
                pageWidth / 2,
                footerY + 18,
                { align: 'center' }
            );
            
            // Decorative elements in footer (removed circles)
        }
    }

    static exportToPDF = async (activityData: ActivityData, stats: ActivityStats, options?: ExportOptions): Promise<void> => {
        return new Promise((resolve) => {
            // Create PDF document with enhanced settings
            const doc = new jsPDF({
                orientation: 'portrait',
                unit: 'mm',
                format: 'a4',
                putOnlyUsedFonts: true,
                floatPrecision: 16
            });
            
            // --- NOTA IMPORTANTE SOBRE FONTES ---
            // Se você continuar a ter problemas com caracteres especiais (como Ø, Ü, Ê) ou emojis,
            // você precisará incorporar uma fonte personalizada que suporte Unicode.
            // Exemplo (assumindo que você converteu 'MinhaFonteUnicode.ttf' para um arquivo de fonte jsPDF):
            // import { MinhaFonteUnicode } from './MinhaFonteUnicode-normal'; // Ou onde quer que sua fonte esteja
            // doc.addFileToVFS('MinhaFonteUnicode.ttf', MinhaFonteUnicode);
            // doc.addFont('MinhaFonteUnicode.ttf', 'MinhaFonteUnicode', 'normal');
            // doc.setFont('MinhaFonteUnicode'); // Defina esta como a fonte padrão
            // Você pode precisar definir fontes para variantes em negrito/itálico também.
            // Por enquanto, removi os emojis do texto para evitar caracteres estranhos se nenhuma fonte Unicode for usada.
            // ------------------------------------

            // Set page background with modern gradient
            const pageWidth = doc.internal.pageSize.getWidth();
            const pageHeight = doc.internal.pageSize.getHeight();
            this.addRect(doc, 0, 0, pageWidth, pageHeight, this.colors.background.main);
            
            // Build document sections with modern spacing
            let yPos = this.addHeader(doc, activityData);
            yPos = this.addCompaniesSection(doc, activityData, yPos);
            
            if (options?.includeStats !== false) {
                yPos = this.addStatsSection(doc, stats, yPos);
            }
            
            // Activities section with modern title
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(typography.sizes.title);
            doc.setTextColor(this.colors.primary[0], this.colors.primary[1], this.colors.primary[2]);
            doc.text('Atividades Realizadas', layout.margins.left + 5, yPos);
            
            // Modern divider line
            doc.setDrawColor(this.colors.secondary[0], this.colors.secondary[1], this.colors.secondary[2]);
            doc.setLineWidth(2);
            doc.line(layout.margins.left + 5, yPos + 5, pageWidth - layout.margins.right - 5, yPos + 5);
            yPos += layout.spacing.xl;

            // Add each activity card (with page break protection)
            activityData.entries.forEach((entry, index) => {
                yPos = this.addActivityCard(doc, entry, index, yPos);
            });

            // Add watermark if provided
            if (options?.watermark) {
                this.addWatermark(doc, options.watermark);
            }

            // Add footer to all pages
            this.addFooter(doc, activityData);

            // Generate modern filename with company prefix
            const timestamp = new Date().toISOString().split('T')[0];
            const companyPrefix = activityData.companies.executing_company
                .replace(/[^a-zA-Z0-9]/g, '_')
                .substring(0, 10)
                .toUpperCase();
            const fileName = `${companyPrefix}_Relatorio_Atividades_${timestamp}.pdf`;
            
            // Save with enhanced options
            doc.save(fileName);
            
            // Provide user feedback
            console.log(`✅ PDF moderno gerado com sucesso: ${fileName}`);
            console.log(`${activityData.entries.length} atividades exportadas`);
            console.log(`🎨 Tema moderno aplicado com cantos arredondados`);
            
            setTimeout(resolve, 100);
        });
    };

    // Add watermark functionality
    private static addWatermark(doc: jsPDF, watermarkText: string) {
        const totalPages = doc.getNumberOfPages();
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        
        for (let i = 1; i <= totalPages; i++) {
            doc.setPage(i);
            
            // Rotate and add watermark text
            doc.saveGraphicsState();
            doc.setGState(doc.GState({ opacity: 0.1 }));
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(60);
            doc.setTextColor(this.colors.text.muted[0], this.colors.text.muted[1], this.colors.text.muted[2]);
            
            // Center the watermark and rotate
            const centerX = pageWidth / 2;
            const centerY = pageHeight / 2;
            doc.text(watermarkText, centerX, centerY, {
                align: 'center',
                angle: 45
            });
            
            doc.restoreGraphicsState();
        }
    }

    // Enhanced export function with theme selection
    static exportToPDFWithTheme = async (
        activityData: ActivityData,
        stats: ActivityStats,
        themeName: string = 'modern',
        includeWatermark: boolean = false
    ): Promise<void> => {
        const options: ExportOptions = {
            theme: modernTechTheme, // Always use modern theme for now
            includeStats: true,
            watermark: includeWatermark ? 'MODULARYS' : undefined
        };
        
        return this.exportToPDF(activityData, stats, options);
    };
}

export default PDFExport;
